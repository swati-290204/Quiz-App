import React, { useState, useEffect, useRef } from 'react';

export default function Quiz({ questions, onFinish, onCancel }){
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isLocked, setIsLocked] = useState(false);
  const timerRef = useRef(null);

  useEffect(()=>{
    setTimeLeft(30);
    setIsLocked(false);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(()=> setTimeLeft(t=>t-1), 1000);
    return ()=> clearInterval(timerRef.current);
  }, [current]);

  useEffect(()=>{
    if (timeLeft <= 0 && !isLocked){
      handleOption(null, true);
    }
  }, [timeLeft, isLocked]);

  if (!questions || questions.length === 0){
    return <div><h2>No questions loaded</h2><div className='footer'><button className='btn' onClick={onCancel}>Back</button></div></div>;
  }

  const handleOption = (opt, timedOut=false) => {
    if (isLocked) return;
    const correct = questions[current].answer;
    const entry = { question: questions[current].question, selected: opt, correct, timedOut };
    setAnswers(prev=>[...prev, entry]);
    setIsLocked(true);
    clearInterval(timerRef.current);
    setTimeout(()=>{
      if (current < questions.length -1){
        setCurrent(c=>c+1);
        setIsLocked(false);
      } else {
        const score = [...answers, entry].filter(a=>a.selected === a.correct).length;
        onFinish({ score, total: questions.length, answers: [...answers, entry] });
      }
    }, 600);
  };

  return (
    <div>
      <div className="header">
        <div>
          <h2>Question {current+1} / {questions.length}</h2>
          <div className="progress">
            <div className="small">Progress: {current}/{questions.length}</div>
            <div className={`small`} aria-live="polite">{timeLeft}s</div>
          </div>
        </div>
        <div className="controls">
          <button className="btn" onClick={onCancel}>Quit</button>
        </div>
      </div>

      <div className="question-box">
        <div style={{fontWeight:600}}>{questions[current].question}</div>
        <div className="options">
          {questions[current].options.map((opt, idx)=>(
            <button key={idx} className="option-btn" onClick={()=>handleOption(opt,false)} aria-label={`Option ${idx+1}`}>
              <strong style={{marginRight:8}}>{idx+1}.</strong>{opt}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

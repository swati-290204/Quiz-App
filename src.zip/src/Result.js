import React, { useEffect, useState } from 'react';

export default function Result({ result, onRestart, onHome }){
  const [history, setHistory] = useState([]);

  useEffect(()=>{
    if (!result) return;
    const entry = { date: new Date().toISOString(), score: result.score, total: result.total };
    const h = JSON.parse(localStorage.getItem('quiz_history') || '[]');
    h.unshift(entry);
    const trimmed = h.slice(0,5);
    localStorage.setItem('quiz_history', JSON.stringify(trimmed));
    setHistory(trimmed);
  },[result]);

  if (!result){
    return <div><h2>No result</h2><div className='footer'><button className='btn' onClick={onHome}>Home</button></div></div>;
  }

  return (
    <div>
      <div className="header">
        <div>
          <h1>Quiz Completed!</h1>
          <p className="small">Final score and summary</p>
        </div>
        <div className="controls">
          <button className="btn" onClick={onRestart}>Retry</button>
          <button className="btn" onClick={onHome}>Home</button>
        </div>
      </div>

      <h2>Score: {result.score} / {result.total}</h2>
      <div className="result-list">
        {result.answers.map((a, idx)=>(
          <div key={idx} className="result-item">
            <div style={{flex:1}}>
              <div style={{fontWeight:600}}>{a.question}</div>
              <div className="small">Your answer: <span className={a.selected===a.correct ? 'correct' : 'incorrect'}>{a.selected ?? 'No answer'}</span></div>
              {a.selected !== a.correct && <div className="small">Correct answer: <span className="correct">{a.correct}</span></div>}
              {a.timedOut && <div className="small">Timed out</div>}
            </div>
            <div style={{minWidth:80,textAlign:'right'}}>{a.selected===a.correct ? <div className='correct'>Correct</div> : <div className='incorrect'>Wrong</div>}</div>
          </div>
        ))}
      </div>

      <div className="history">
        <h2 style={{marginTop:16}}>Last 5 Results</h2>
        {history.map((h,i)=>(
          <div key={i} className="history-item">
            <div>{new Date(h.date).toLocaleString()}</div>
            <div>{h.score} / {h.total}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

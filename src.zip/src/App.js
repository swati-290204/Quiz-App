import React, { useState } from 'react';
import Home from './Home';
import Quiz from './Quiz';
import Result from './Result';

export default function App(){
  const [step, setStep] = useState('home');
  const [questions, setQuestions] = useState([]);
  const [result, setResult] = useState(null);

  const startQuiz = async (config) => {
    try{
      const res = await fetch('/questions.json');
      let data = await res.json();
      // apply difficulty filter if needed
      // for local questions, no difficulty metadata - so just slice
      data = data.slice(0, config.amount || 10);
      setQuestions(data);
      setResult(null);
      setStep('quiz');
    }catch(e){
      alert('Failed to load questions: '+e.message);
    }
  };

  const finishQuiz = (resObj) => {
    setResult(resObj);
    setStep('result');
  };

  const goHome = () => { setStep('home'); setQuestions([]); setResult(null); };

  return (
    <div className="app" role="application" aria-label="Quiz App">
      <div className="container">
        {step === 'home' && <Home onStart={startQuiz} />}
        {step === 'quiz' && <Quiz questions={questions} onFinish={finishQuiz} onCancel={goHome} />}
        {step === 'result' && <Result result={result} onRestart={() => startQuiz({amount:10})} onHome={goHome} />}
      </div>
    </div>
  );
}

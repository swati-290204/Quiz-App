import React, { useState, useEffect } from 'react';

export default function Home({ onStart }){
  const [source, setSource] = useState('local');
  const [difficulty, setDifficulty] = useState('any');
  const [timer, setTimer] = useState(30);
  const [history, setHistory] = useState([]);

  useEffect(()=>{
    const h = JSON.parse(localStorage.getItem('quiz_history') || '[]');
    setHistory(h.slice(0,5));
  },[]);

  const handleStart = () => {
    onStart({ source, difficulty, amount: 10, timer });
  };

  return (
    <div>
      <div className="header" style={{alignItems:'flex-start'}}>
        <h1 className="title">Quiz App</h1>
        <div className="small">Ready? Select options and Start</div>
      </div>

      <div className="home-vertical" role="form" aria-label="Start quiz form">

        <div>
          <div className="label">1. Question source</div>
          <select className="select" value={source} onChange={e=>setSource(e.target.value)} aria-label="Question source">
            <option value="local">questions.json (offline)</option>
            <option value="api">Open Trivia DB (online)</option>
          </select>
        </div>

        <div>
          <div className="label">2. Difficulty</div>
          <select className="select" value={difficulty} onChange={e=>setDifficulty(e.target.value)} aria-label="Difficulty">
            <option value="any">Any</option>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </div>

        <div>
          <div className="label">3. Number of questions</div>
          <div className="info">10 (fixed)</div>
        </div>

        <div>
          <div className="label">4. Timer per question (seconds)</div>
          <select className="select" value={timer} onChange={e=>setTimer(Number(e.target.value))} aria-label="Timer per question">
            <option value={15}>15</option>
            <option value={20}>20</option>
            <option value={30}>30</option>
            <option value={45}>45</option>
          </select>
        </div>

        <div className="start-wrap">
          <button className="btn" onClick={handleStart} aria-label="Start Quiz">Start Quiz</button>
        </div>
      </div>

      <div className="history">
        <h2 style={{marginTop:16}}>Last Results</h2>
        {history.length === 0 && <div className="small">No previous quiz results.</div>}
        {history.map((item, idx)=>(
          <div key={idx} className="history-item">
            <div>{new Date(item.date).toLocaleString()}</div>
            <div>{item.score} / {item.total}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
